# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: nano.spec.ts >> partial reset progress failure reports old records may return
- Location: tests/nano.spec.ts:783:3

# Error details

```
Error: locator.selectOption: Test ended.
Call log:
  - waiting for getByLabel('主役', { exact: true })

```

# Test source

```ts
  687 |     .check();
  688 |   await page.getByRole("button", { name: "予想を固定して場面を比較" }).click();
  689 |   for (let i = 0; i < 5; i++)
  690 |     await page
  691 |       .locator(`input[name=character-answer-${i}]`)
  692 |       .nth(i === 2 ? 1 : 0)
  693 |       .check();
  694 |   await page.getByRole("button", { name: "特徴の判断を確定" }).click();
  695 |   await expect(
  696 |     page.getByRole("status").filter({ hasText: "もう一度" }),
  697 |   ).toContainText("耳の特徴");
  698 | });
  699 | test("review regression: restaurant preserves the base apron color", async ({
  700 |   page,
  701 | }) => {
  702 |   await page.goto("#chapter-7");
  703 |   await step(page, 3);
  704 |   await page.getByLabel("比較する場面", { exact: true }).selectOption("1");
  705 |   await page
  706 |     .getByRole("radio", { name: "必ず同じになる", exact: true })
  707 |     .check();
  708 |   await page.getByRole("button", { name: "予想を固定して場面を比較" }).click();
  709 |   const fills = await page.locator(".nano-pair svg").evaluateAll((svgs) =>
  710 |     svgs.map((svg) =>
  711 |       Array.from(svg.querySelectorAll("path"))
  712 |         .find((p) => p.getAttribute("d")?.startsWith("M259 224"))
  713 |         ?.getAttribute("fill"),
  714 |     ),
  715 |   );
  716 |   expect(fills).toEqual(["#e7b35b", "#e7b35b"]);
  717 | });
  718 | test("review regression: photo scene visually changes the kitchen and pose", async ({
  719 |   page,
  720 | }) => {
  721 |   await page.goto("#chapter-7");
  722 |   await step(page, 3);
  723 |   await page.getByLabel("比較する場面", { exact: true }).selectOption("2");
  724 |   await page
  725 |     .getByRole("radio", { name: "必ず同じになる", exact: true })
  726 |     .check();
  727 |   await page.getByRole("button", { name: "予想を固定して場面を比較" }).click();
  728 |   const after = page.locator(".nano-pair svg").nth(1);
  729 |   await expect(
  730 |     after.locator('path[d="M0 321h154v22H0M409 321h191v22H409"]'),
  731 |   ).toHaveCount(0);
  732 |   await expect(after.locator("[data-photo-backdrop]")).toHaveCount(1);
  733 |   await expect(after.locator("desc")).toContainText("手を振る");
  734 | });
  735 | for (const failOld of [false, true])
  736 |   test(`newer copy survives old ${failOld ? "failure" : "success"} after text changes`, async ({
  737 |     page,
  738 |   }) => {
  739 |     await page.addInitScript(() => {
  740 |       const pending: { resolve: () => void; reject: () => void }[] = [];
  741 |       (window as unknown as { pending: typeof pending }).pending = pending;
  742 |       Object.defineProperty(navigator, "clipboard", {
  743 |         value: {
  744 |           writeText: () =>
  745 |             new Promise<void>((resolve, reject) =>
  746 |               pending.push({ resolve, reject: () => reject(Error("denied")) }),
  747 |             ),
  748 |         },
  749 |       });
  750 |     });
  751 |     await page.goto("#chapter-7");
  752 |     await page.getByRole("button", { name: "指示文を全文コピー" }).click();
  753 |     await page.getByLabel("主役", { exact: true }).selectOption("1");
  754 |     await page.getByRole("button", { name: "指示文を全文コピー" }).click();
  755 |     await expect
  756 |       .poll(() =>
  757 |         page.evaluate(
  758 |           () => (window as unknown as { pending: unknown[] }).pending.length,
  759 |         ),
  760 |       )
  761 |       .toBe(2);
  762 |     await page.evaluate((fail) => {
  763 |       const p = (
  764 |         window as unknown as {
  765 |           pending: { resolve: () => void; reject: () => void }[];
  766 |         }
  767 |       ).pending[0];
  768 |       (fail ? p.reject : p.resolve)();
  769 |     }, failOld);
  770 |     await expect(
  771 |       page.getByRole("button", { name: "指示文を全文コピー" }),
  772 |     ).toBeDisabled();
  773 |     expect((await stored(page)).copied ?? []).toEqual([]);
  774 |     await page.evaluate(() =>
  775 |       (
  776 |         window as unknown as { pending: { resolve: () => void }[] }
  777 |       ).pending[1].resolve(),
  778 |     );
  779 |     await expect(page.getByText(/この本文のコピー成功履歴/)).toBeVisible();
  780 |     expect((await stored(page)).copied).toHaveLength(1);
  781 |   });
  782 | for (const failure of ["chapter", "progress"])
  783 |   test(`partial reset ${failure} failure reports old records may return`, async ({
  784 |     page,
  785 |   }) => {
  786 |     await page.goto("#chapter-7");
> 787 |     await page.getByLabel("主役", { exact: true }).selectOption("2");
      |                                                  ^ Error: locator.selectOption: Test ended.
  788 |     await page.getByLabel(/第7章を学習した/).check();
  789 |     await page.evaluate(
  790 |       ({ key, failure }) => {
  791 |         const remove = Storage.prototype.removeItem,
  792 |           set = Storage.prototype.setItem;
  793 |         Storage.prototype.removeItem = function (k) {
  794 |           if (failure === "chapter" && k === key) throw Error("denied");
  795 |           return remove.call(this, k);
  796 |         };
  797 |         Storage.prototype.setItem = function (k, v) {
  798 |           if (failure === "progress" && k === "gemini-toranomaki:progress:v1")
  799 |             throw Error("denied");
  800 |           return set.call(this, k, v);
  801 |         };
  802 |       },
  803 |       { key: nanoKey, failure },
  804 |     );
  805 |     await page.getByRole("button", { name: "第7章だけを初期化" }).click();
  806 |     await page.getByRole("button", { name: "第7章の記録を消す" }).click();
  807 |     await expect(
  808 |       page.getByRole("status").filter({ hasText: "削除を確認できません" }),
  809 |     ).toBeVisible();
  810 |     await expect(page.getByLabel("主役", { exact: true })).toHaveValue("0");
  811 |     await expect(page.getByLabel(/第7章を学習した/)).not.toBeChecked();
  812 |     await page.reload();
  813 |     await expect(page.getByLabel("主役", { exact: true })).toHaveValue(
  814 |       failure === "chapter" ? "2" : "0",
  815 |     );
  816 |     await expect(page.getByLabel(/第7章を学習した/)).toBeChecked({
  817 |       checked: failure === "progress",
  818 |     });
  819 |   });
  820 | test("200 percent text preserves narrow controls and observation alternatives", async ({
  821 |   page,
  822 | }) => {
  823 |   await page.setViewportSize({ width: 375, height: 900 });
  824 |   await page.goto("#chapter-7");
  825 |   await page.addStyleTag({ content: "html { font-size:200%; }" });
  826 |   await openChallenge(page);
  827 |   await page.getByText("文字で観察する（画像の代替）", { exact: true }).click();
  828 |   await page.getByRole("checkbox", { name: "料理帽", exact: true }).check();
  829 |   await page.getByRole("checkbox", { name: "目", exact: true }).check();
  830 |   await submit(page);
  831 |   await expect(
  832 |     page.getByText("観察は一致しています。", { exact: true }),
  833 |   ).toBeVisible();
  834 |   expect(
  835 |     await page.evaluate(
  836 |       () => document.documentElement.scrollWidth <= innerWidth,
  837 |     ),
  838 |   ).toBe(true);
  839 | });
  840 | 
```