# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: app.spec.ts >> navigation, lesson, copy, quiz, progress and reset
- Location: tests/app.spec.ts:2:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: '準備中', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: '準備中', exact: true }) with timeout 5000ms
  - waiting for getByRole('heading', { name: '準備中', exact: true })

```

```yaml
- link "本文へ移動":
  - /url: "#main"
- banner:
  - link "虎の巻 GEMINI GUIDE":
    - /url: "#home"
  - button "ダークテーマに切り替え": ☾ ダーク
- navigation "メインナビゲーション":
  - link "ホーム":
    - /url: "#home"
  - link "全10章・機能一覧":
    - /url: "#curriculum"
  - link "Gemini体験ラボ":
    - /url: "#lab"
  - link "第1章を学ぶ":
    - /url: "#chapter-1"
  - link "第2章を学ぶ":
    - /url: "#chapter-2"
  - link "第3章を学ぶ":
    - /url: "#chapter-3"
  - link "第4章を学ぶ":
    - /url: "#chapter-4"
  - link "第5章を学ぶ":
    - /url: "#chapter-5"
  - link "第6章を学ぶ":
    - /url: "#chapter-6"
  - link "第7章を学ぶ":
    - /url: "#chapter-7"
  - link "第8章を学ぶ":
    - /url: "#chapter-8"
  - link "第9章を学ぶ":
    - /url: "#chapter-9"
  - link "第10章を学ぶ":
    - /url: "#chapter-10"
- main:
  - text: 非公式インタラクティブ教材 · v0.2
  - article:
    - link "← 全10章へ":
      - /url: "#curriculum"
    - paragraph: CHAPTER 10
    - heading "総合演習：複数機能を連携させて成果物を作る" [level=1]
    - paragraph: 複数機能を連携させて成果物を作る
    - heading "学習目標" [level=2]
    - paragraph: 課題・根拠・完成条件をつなぎ、AIの誤りと修正による退行を発見して改善する。
    - heading "この機能について" [level=3]
    - paragraph: 3つの架空テーマで、調査・資料整理・制作・10観点の検証・再修正・理由付き振り返りを体験します。全10章の区切りの後も教材開発は続けます。
    - paragraph: 課題設定 → 調査 → 資料整理 → 制作 → 検証 → 改善 → 振り返り。固定データの模擬演習です。実サービスは任意で、外部の結果は教材から検証できません。全10章の区切りの後も、新しい演習・機能変更への対応を続けます。
    - region "総合演習の現在位置":
      - text: 総合演習の工程
      - combobox "総合演習の工程":
        - option "STEP 0 環境を準備" [selected]
        - option "STEP 1 課題と完成条件"
        - option "STEP 2 調査と出典照合"
        - option "STEP 3 資料を整理"
        - option "STEP 4 制作指示と初版"
        - option "STEP 5 品質を検証"
        - option "STEP 6 改善と再検証"
        - option "STEP 7 評価と振り返り"
      - paragraph: 選択内容：STEP 0 環境を準備
      - text: 演習方法
      - combobox "演習方法":
        - option "模擬演習だけで進める" [selected]
        - option "模擬＋任意の実サービス演習"
      - paragraph: 選択内容：模擬演習だけで進める
      - paragraph: 現在位置 STEP 0 / 7 · 閲覧記録 0/8 · 現在の模擬確認 0/8
      - progressbar "現在の模擬課題の確認数"
      - paragraph: 工程への移動は達成や外部操作の成功を意味しません。どの工程からでも再挑戦できます。
    - heading "STEP 0 環境を準備" [level=2]
    - text: 教材とサービスの配置
    - combobox "教材とサービスの配置":
      - option "PC：ブラウザの分割表示" [selected]
      - option "PC：別ウィンドウ"
      - option "PC：別タブ"
      - option "スマートフォン：タブ・アプリ切替"
    - paragraph: 選択内容：PC：ブラウザの分割表示
    - paragraph: ブラウザの標準分割機能で左に教材、右にGeminiを置きます。分割機能がない場合は別ウィンドウを選べます。
    - list:
      - listitem: 教材の現在位置を確認する。
      - listitem: 実操作する場合だけ、別タブの利用条件とアカウントを確認する。
      - listitem: 機能が利用できなければ模擬演習を続ける。契約・アップロードは不要。
    - paragraph: 教材はブラウザを分割・埋込みせず、Googleへのログイン、OAuth、メール送信、API実行、ファイルアップロードも行いません。
    - complementary "課題と資料":
      - heading "今回の課題" [level=3]
      - paragraph: 架空の青葉町・読書室の歩み
      - paragraph: 史料が示す範囲で町の読書室を紹介する
      - paragraph: 小さなWeb展示・確認問題／テーマの初学者
      - heading "完成条件" [level=4]
      - list:
        - listitem: 原文と出典IDを示す
        - listitem: 不明点と対象範囲を明示
        - listitem: 確認問題と解説を付ける
      - paragraph: 第3・4章：調査と資料整理、第6章：試作と検証、第9章：再利用する指示の考え方を応用。Skillsでこれらの機能が自動実行されるとは案内しません。
    - heading "段階的ヒント（任意）" [level=3]
    - button "ヒントを1段階開く"
    - button "この工程の固定課題を確認"
    - status
    - button "この工程から再挑戦"
    - paragraph: 現在の模擬確認：なし。過去の達成履歴：0件。過去のコピー履歴：0件。実操作自己申告：0/8工程。成果物自己評価：0/6軸。
    - button "← 前の工程" [disabled]
    - button "次の工程 →"
    - paragraph: 第10章だけの初期化は専用記録と第10章の完了を対象にします。下部の「進捗を初期化」は従来どおり全章の完了だけを対象にし、専用記録を消しません。
    - button "第10章の記録だけを初期化"
    - heading "利用条件・公式参考情報" [level=2]
    - paragraph: 固定模擬だけで学習可能。実Deep Researchは18歳以上・ログインが必要。Notebook系の接続・アクティビティ設定・段階提供やプラン・地域・組織で条件が異なります。個別アカウントでの利用可否は未確認です。
    - list:
      - listitem: "章題はIssue #1に基づく教材上の名称です。最新の公式名称・画面表示を保証しません。"
      - listitem: 機密情報・個人情報を練習に入力しないでください。
    - paragraph:
      - link "Deep Researchの計画・上限・コピー ↗（別タブ）":
        - /url: https://support.google.com/gemini/answer/15719111?co=GENIE.Platform%3DDesktop&hl=ja
    - paragraph:
      - link "Gemini内ノートブック・接続と同期条件 ↗（別タブ）":
        - /url: https://support.google.com/gemini/answer/16972047?co=GENIE.Platform%3DDesktop&hl=ja
    - paragraph:
      - link "Notebook系の資料追加・コピーしたテキスト ↗（別タブ）":
        - /url: https://support.google.com/gemininotebook/answer/16215270?hl=ja
    - paragraph:
      - link "Canvasの制作・修正・版の確認 ↗（別タブ）":
        - /url: https://support.google.com/gemini/answer/16047321?co=GENIE.Platform%3DDesktop&hl=ja
    - paragraph: 情報確認状況：2026-11-06：Google公式本文を確認。実Google操作・日本語の実UI・個別権限は未検証。
  - region "学習進捗":
    - heading "あなたの学習進捗" [level=2]
    - strong: 0 / 10章
    - progressbar "全10章の完了数"
    - paragraph: 全10章を自分のペースで学びましょう。 学習できる章：10章
    - button "進捗を初期化"
  - status
- contentinfo:
  - strong: Gemini活用 虎の巻
  - paragraph: Googleが提供・監修するものではない、非公式の学習教材です。Googleのロゴ・公式画像は使用していません。
  - 'link "教材の仕様・更新状況（Issue #1）"':
    - /url: https://github.com/tetsujisugimori-coder/gemini-toranomaki/issues/1
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | test("navigation, lesson, copy, quiz, progress and reset", async ({ page }) => {
  3   |   await page.addInitScript(() => {
  4   |     Object.defineProperty(navigator, "clipboard", {
  5   |       configurable: true,
  6   |       value: {
  7   |         writeText: async (text: string) => {
  8   |           (window as unknown as { copied: string }).copied = text;
  9   |         },
  10  |       },
  11  |     });
  12  |   });
  13  |   await page.goto("");
  14  |   await page.getByRole("link", { name: "全10章・機能一覧" }).click();
  15  |   await expect(page.locator(".chapter-row")).toHaveCount(10);
  16  |   await page.locator(".chapter-row").nth(9).click();
  17  |   await expect(
  18  |     page.getByRole("heading", { name: "準備中", exact: true }),
> 19  |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  20  |   await page.getByRole("link", { name: "第1章を学ぶ", exact: true }).click();
  21  |   await page.getByText("1. 別画面でGeminiを開く", { exact: true }).click();
  22  |   await expect(page.getByText(/この教材を残したまま/)).toBeVisible();
  23  |   await page.getByText("プロンプト全文を表示", { exact: true }).click();
  24  |   await expect(page.locator("pre")).toContainText("Geminiを初めて使います");
  25  |   await page.getByRole("button", { name: "プロンプト全文をコピー" }).click();
  26  |   await expect(page.getByRole("status").last()).toContainText("コピーしました");
  27  |   expect(
  28  |     await page.evaluate(() => (window as unknown as { copied: string }).copied),
  29  |   ).toContain("断定しないでください");
  30  |   await page.getByLabel("Geminiの回答だけで利用可能だと判断する").check();
  31  |   await expect(page.getByText(/もう一度考えて/)).toBeVisible();
  32  |   await page
  33  |     .getByLabel(
  34  |       "自分の画面と公式情報を確認し、プラン・端末などの違いを考慮する",
  35  |     )
  36  |     .check();
  37  |   await expect(page.getByText(/正解です/)).toBeVisible();
  38  |   await page.getByRole("checkbox").check();
  39  |   await page.reload();
  40  |   await expect(page.getByRole("checkbox")).toBeChecked();
  41  |   await expect(page.getByText("1 / 10章", { exact: true })).toBeVisible();
  42  |   await page.getByRole("button", { name: "進捗を初期化", exact: true }).click();
  43  |   await page.getByRole("button", { name: "キャンセル" }).click();
  44  |   await expect(page.getByRole("checkbox")).toBeChecked();
  45  |   await page.getByRole("button", { name: "進捗を初期化", exact: true }).click();
  46  |   await page.getByRole("button", { name: "初期化する", exact: true }).click();
  47  |   await page.reload();
  48  |   await expect(page.getByRole("checkbox")).not.toBeChecked();
  49  | });
  50  | test("blocked storage and clipboard provide feedback", async ({ page }) => {
  51  |   await page.addInitScript(() => {
  52  |     Object.defineProperty(window, "localStorage", {
  53  |       get() {
  54  |         throw Error("blocked");
  55  |       },
  56  |     });
  57  |     Object.defineProperty(navigator, "clipboard", {
  58  |       value: {
  59  |         writeText: async () => {
  60  |           throw Error("denied");
  61  |         },
  62  |       },
  63  |     });
  64  |   });
  65  |   await page.goto("#chapter-1");
  66  |   await page.getByRole("checkbox").check();
  67  |   await expect(page.getByText(/ブラウザに保存できません/)).toBeVisible();
  68  |   await page.getByRole("button", { name: "プロンプト全文をコピー" }).click();
  69  |   await expect(page.getByRole("status").last()).toContainText(
  70  |     "コピーできませんでした",
  71  |   );
  72  | });
  73  | for (const width of [375, 390, 1280])
  74  |   test(`layout and keyboard at ${width}px`, async ({ page }) => {
  75  |     await page.setViewportSize({ width, height: 900 });
  76  |     await page.goto("");
  77  |     await expect(page.locator(".brand")).toBeVisible();
  78  |     await page.keyboard.press("Tab");
  79  |     await expect(page.getByRole("link", { name: "本文へ移動" })).toBeFocused();
  80  |     for (const theme of ["light", "dark"]) {
  81  |       await page.emulateMedia({ colorScheme: theme as "light" | "dark" });
  82  |       await page.reload();
  83  |       await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
  84  |       await page.screenshot({
  85  |         path: `test-results/${test.info().project.name}-${width}-${theme}.png`,
  86  |         fullPage: true,
  87  |       });
  88  |       expect(
  89  |         await page.evaluate(
  90  |           () => document.documentElement.scrollWidth <= innerWidth,
  91  |         ),
  92  |       ).toBe(true);
  93  |       await page.goto("#chapter-1");
  94  |       await page.getByText("プロンプト全文を表示", { exact: true }).click();
  95  |       expect(
  96  |         await page.evaluate(
  97  |           () => document.documentElement.scrollWidth <= innerWidth,
  98  |         ),
  99  |       ).toBe(true);
  100 |       await page.goto("");
  101 |     }
  102 |   });
  103 | 
  104 | for (const route of ["home", "chapter-1"]) {
  105 |   test(`skip link preserves ${route} URL, reload and back history`, async ({
  106 |     page,
  107 |   }) => {
  108 |     await page.goto("#curriculum");
  109 |     await page
  110 |       .getByRole("link", {
  111 |         name: route === "home" ? "ホーム" : "第1章を学ぶ",
  112 |         exact: true,
  113 |       })
  114 |       .click();
  115 |     const title = page.locator("h1");
  116 |     const heading =
  117 |       route === "home" ? "Gemini活用虎の巻" : "Geminiの画面とモデル選択";
  118 |     // Hash changes before React commits the destination view. Wait for the
  119 |     // intended page rather than capturing the previous page's heading.
```