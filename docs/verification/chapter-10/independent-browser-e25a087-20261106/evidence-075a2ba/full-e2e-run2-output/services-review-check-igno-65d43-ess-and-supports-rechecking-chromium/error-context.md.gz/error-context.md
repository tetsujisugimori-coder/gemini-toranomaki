# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: services-review.spec.ts >> check ignores stale registration copy success and supports rechecking
- Location: tests/services-review.spec.ts:74:5

# Error details

```
Error: locator.click: Test ended.
Call log:
  - waiting for getByRole('button', { name: /^4\. / })

```

# Test source

```ts
  1   | import { test, expect, type Page } from "@playwright/test";
  2   | import { reviewItems } from "../src/services-data";
  3   | import { servicesKey } from "../src/services-storage";
  4   | 
  5   | // Existing suite verifies the preserved mock/legacy path; new practice has its own suite.
  6   | test.beforeEach(async ({ page }) => {
  7   |   await page.addInitScript(() => {
  8   |     if (!localStorage.getItem('gemini-toranomaki:services-practice:v1'))
  9   |       localStorage.setItem('gemini-toranomaki:services-practice:v1', JSON.stringify({mode:'mock'}));
  10  |   });
  11  | });
  12  | 
  13  | const step = (page: Page, n: number) =>
> 14  |   page.getByRole("button", { name: new RegExp(`^${n}\\. `) }).click();
      |                                                               ^ Error: locator.click: Test ended.
  15  | async function approveMock(page: Page) {
  16  |   await step(page, 4);
  17  |   await page.getByLabel("比較するケース").selectOption("correct");
  18  |   for (const item of reviewItems)
  19  |     await page.getByLabel(item, { exact: true }).check();
  20  |   await page.getByRole("button", { name: "確認済みの模擬内容で次へ" }).click();
  21  |   await step(page, 3);
  22  | }
  23  | interface PendingCopy {
  24  |   text: string;
  25  |   resolve: () => void;
  26  |   reject: (reason: Error) => void;
  27  |   promise: Promise<void>;
  28  | }
  29  | type CopyWindow = Window & { reviewCopies: PendingCopy[] };
  30  | async function deferredClipboard(page: Page) {
  31  |   await page.addInitScript(() => {
  32  |     const calls: PendingCopy[] = [];
  33  |     (window as CopyWindow).reviewCopies = calls;
  34  |     Object.defineProperty(navigator, "clipboard", {
  35  |       configurable: true,
  36  |       value: {
  37  |         writeText: (text: string) => {
  38  |           const call = { text } as PendingCopy;
  39  |           call.promise = new Promise<void>((resolve, reject) => {
  40  |             call.resolve = resolve;
  41  |             call.reject = reject;
  42  |           });
  43  |           calls.push(call);
  44  |           return call.promise;
  45  |         },
  46  |       },
  47  |     });
  48  |   });
  49  | }
  50  | async function settle(
  51  |   page: Page,
  52  |   index: number,
  53  |   outcome: "success" | "failure",
  54  | ) {
  55  |   await page.evaluate(
  56  |     async ({ index, outcome }) => {
  57  |       const call = (window as CopyWindow).reviewCopies[index];
  58  |       if (outcome === "success") call.resolve();
  59  |       else call.reject(Error("clipboard denied"));
  60  |       await call.promise.catch(() => {});
  61  |       // Wait for React to render the awaited clipboard result before asserting absence.
  62  |       await new Promise<void>((resolve) =>
  63  |         requestAnimationFrame(() => resolve()),
  64  |       );
  65  |     },
  66  |     { index, outcome },
  67  |   );
  68  | }
  69  | const saved = (page: Page) =>
  70  |   page.evaluate((key) => localStorage.getItem(key), servicesKey);
  71  | 
  72  | for (const action of ["hold", "case", "check", "mode", "leave"] as const)
  73  |   for (const outcome of ["success", "failure"] as const)
  74  |     test(`${action} ignores stale registration copy ${outcome} and supports rechecking`, async ({
  75  |       page,
  76  |     }) => {
  77  |       await deferredClipboard(page);
  78  |       await page.goto("#chapter-2");
  79  |       await approveMock(page);
  80  |       await page
  81  |         .getByRole("button", { name: "登録依頼を全文コピー", exact: true })
  82  |         .click();
  83  |       expect(
  84  |         await page.evaluate(() => (window as CopyWindow).reviewCopies[0].text),
  85  |       ).toContain("実登録禁止");
  86  |       if (action === "mode") {
  87  |         await page
  88  |           .getByLabel("任意の実アカウント演習（自分の非機密メール）", {
  89  |             exact: true,
  90  |           })
  91  |           .check();
  92  |       } else if (action === "leave") {
  93  |         await page.getByRole("link", { name: "ホーム", exact: true }).click();
  94  |         await page
  95  |           .getByRole("link", { name: "第2章を学ぶ", exact: true })
  96  |           .click();
  97  |       } else {
  98  |         await step(page, 4);
  99  |         if (action === "hold")
  100 |           await page
  101 |             .getByRole("button", { name: "登録せず確認する", exact: true })
  102 |             .click();
  103 |         if (action === "case")
  104 |           await page.getByLabel("比較するケース").selectOption("duplicate");
  105 |         if (action === "check")
  106 |           await page.getByLabel(reviewItems[0], { exact: true }).uncheck();
  107 |       }
  108 |       const before = await saved(page);
  109 |       await settle(page, 0, outcome);
  110 |       expect(await saved(page)).toBe(before);
  111 |       await expect(page.locator(".services .feedback")).toHaveText("");
  112 |       if (action === "hold")
  113 |         await expect(page.getByText(/^保留しました/)).toBeVisible();
  114 |       if (action === "case")
```